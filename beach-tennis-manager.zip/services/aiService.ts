// Service disabled as requested.
export const generatePlayerProfile = async () => {
  return {};
};